"""
Controlador XPT2046 (panel tactil) para la Orange Pi Zero 2W

Sustituye a xpt2046_circuitpython, que depende de Blinka. Expone los dos
metodos que usa la practica: is_pressed y get_coordinates.

Conexiones          Pin   Puerto   Linea GPIO
  TP_CS              26    PH9      la maneja el kernel (CS1)
  TP_IRQ             11    PH2      226
  MOSI               19    PH7      bus SPI1, compartido con la pantalla
  MISO               21    PH8      bus SPI1, compartido con la pantalla
  SCLK               23    PH6      bus SPI1, compartido con la pantalla

El panel entrega lecturas de 12 bits sin calibrar: convertirlas a
coordenadas de pantalla es el trabajo de 3_calibracion.py.
"""

from periphery import GPIO, SPI

# Byte de control: bit 7 inicia, los bits 6 a 4 eligen el canal
CMD_X = 0xD0
CMD_Y = 0x90

CHIP = "/dev/gpiochip0"


class Touch:
    """Panel tactil XPT2046 sobre SPI, con la interrupcion por GPIO."""

    def __init__(self, bus=1, dispositivo=1, irq=226, baudrate=2000000):
        ruta = "/dev/spidev%d.%d" % (bus, dispositivo)
        self._spi = SPI(ruta, 0, baudrate)
        self._irq = GPIO(CHIP, irq, "in")

    def is_pressed(self):
        return not self._irq.read()     # la linea baja al tocar

    def get_coordinates(self):
        return self._leer(CMD_X), self._leer(CMD_Y)

    def _leer(self, comando):
        r = self._spi.transfer([comando, 0x00, 0x00])
        return ((r[1] << 8) | r[2]) >> 3    # el dato util son 12 bits

    def cerrar(self):
        self._spi.close()
        self._irq.close()
