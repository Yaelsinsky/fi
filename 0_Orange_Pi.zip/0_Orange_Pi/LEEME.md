# Programas para la Orange Pi Zero 2W

✅ Los tres probados en la placa el 2026-10-12, con Debian 12 (bookworm) y `python-periphery`, a 40 MHz: la misma velocidad que la Raspberry.

| Archivo | Que es |
| --- | --- |
| `ili9341_opi.py`   | controlador de la pantalla |
| `xpt2046_opi.py`   | controlador del panel táctil |
| `1_prueba_lcd.py`  | figuras, imagen y texto |
| `2_puntos.py`      | cinco puntos rebotando |
| `3_calibracion.py` | calibra el panel y dibuja con el dedo |
| `golden`           | imagen de prueba del programa 1 |

Los dos primeros no se ejecutan solos: los importan los otros tres.

## Por qué existen los controladores

Adafruit Blinka no reconoce la Orange Pi Zero 2W, así que no sirven `board`, `digitalio`, `busio`, `adafruit_rgb_display` ni `xpt2046_circuitpython`. Los dos controladores hacen ese trabajo sobre `python-periphery`, que habla directo con `/dev/spidev*` y `/dev/gpiochip*`.

Exponen los mismos nombres que usa Adafruit, así que **el cuerpo de los tres programas es idéntico al de la versión para Raspberry**: lo único que cambia es el encabezado. Esa es la comparación que hace el alumno.

## Datos de hardware

| Señal | Pin | Puerto | Línea GPIO |
| --- | --- | --- | --- |
| TP_IRQ | 11 | PH2 | 226 |
| RST    | 13 | PH3 | 227 |
| DC     | 15 | PI5 | 261 |
| LCD_CS | 24 | PH5 | 229 |

| Dispositivo | Bus | Chip select | Nodo |
| --- | --- | --- | --- |
| Pantalla ILI9341 | 1 | 0 | `/dev/spidev1.0` |
| Panel XPT2046    | 1 | 1 | `/dev/spidev1.1` |

⚠️ El *chip select* de la pantalla (PH5, línea 229) **lo maneja `ili9341_opi.py`, no el kernel**: el overlay `spi1-cs0-spidev` crea el nodo pero no le asigna el pin, así que CS0 nunca bajaría y la pantalla quedaría en blanco sin error. El CS1 del panel táctil (PH9) sí lo maneja el kernel, por eso `xpt2046_opi.py` no lo toca.

| Archivo extra | Para que |
| --- | --- |
| `diagnostico.py` | prueba de lo simple a lo complejo y dice dónde falla |
