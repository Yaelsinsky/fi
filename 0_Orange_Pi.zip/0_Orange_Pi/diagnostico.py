"""
Diagnostico de la pantalla ILI9341 en la Orange Pi Zero 2W

Corre pruebas de la mas simple a la mas compleja y dice en cual falla.
No usa ili9341_opi.py: habla con periphery directo, para separar un
error del controlador de un problema de hardware o de permisos.

Uso:  python diagnostico.py
"""

import os
import time

PANTALLA = "/dev/spidev1.0"
TACTIL = "/dev/spidev1.1"
CHIP = "/dev/gpiochip0"

DC = 261                # PI5, pin 15
RST = 227               # PH3, pin 13
IRQ = 226               # PH2, pin 11

LENTO = 4000000         # velocidad conservadora para diagnosticar


def titulo(n, texto):
    print("\n" + "=" * 58)
    print("PRUEBA %d: %s" % (n, texto))
    print("=" * 58)


# ----- 1. Los dispositivos -----
titulo(1, "existen los dispositivos y se pueden abrir")
falla = False
for ruta in (PANTALLA, TACTIL, CHIP):
    if not os.path.exists(ruta):
        print("  FALTA     %s" % ruta)
        falla = True
    else:
        r = os.access(ruta, os.R_OK)
        w = os.access(ruta, os.W_OK)
        print("  %s  lectura=%s escritura=%s" % (ruta, r, w))
        if not (r and w):
            falla = True
if falla:
    print("\n  -> Revisar el paso 1 del manual. Se detiene aqui.")
    raise SystemExit(1)
print("  OK")


# ----- 2. La libreria -----
titulo(2, "periphery se importa")
from periphery import GPIO, SPI
print("  OK")


# ----- 3. Los pines -----
titulo(3, "se pueden tomar y mover los pines")
dc = GPIO(CHIP, DC, "low")
rst = GPIO(CHIP, RST, "high")
irq = GPIO(CHIP, IRQ, "in")
for valor in (True, False, True, False):
    dc.write(valor)
    rst.write(valor)
print("  DC  linea %d: se movio" % DC)
print("  RST linea %d: se movio" % RST)
print("  IRQ linea %d: lee %s  (True = sin tocar)" % (IRQ, irq.read()))
print("  OK")


# ----- 4. El bus, probando el panel tactil -----
titulo(4, "el bus SPI responde (se lee el panel tactil)")
print("  El MISO del modulo solo esta cableado al panel tactil, no a la")
print("  pantalla, asi que esta es la unica forma de comprobar el bus.")
tactil = SPI(TACTIL, 0, 2000000)
lecturas = []
for _ in range(5):
    r = tactil.transfer([0xD0, 0x00, 0x00])
    lecturas.append(((r[1] << 8) | r[2]) >> 3)
    time.sleep(0.05)
print("  Lecturas de X: %s" % lecturas)
if all(v == 0 for v in lecturas):
    print("  -> Todo en cero: el panel no contesta. Revisar MISO y TP_CS.")
elif all(v == 4095 for v in lecturas):
    print("  -> Todo en 4095: MISO se queda en alto. Revisar el cableado.")
else:
    print("  OK: el bus funciona y el chip select CS1 tambien.")
tactil.close()


# ----- 5. La pantalla -----
titulo(5, "la pantalla responde a los comandos")
spi = SPI(PANTALLA, 0, LENTO)


def cmd(c, datos=None):
    dc.write(False)
    spi.transfer([c])
    if datos:
        dc.write(True)
        spi.transfer(datos)


print("  Reset por hardware...")
rst.write(True)
time.sleep(0.05)
rst.write(False)
time.sleep(0.05)
rst.write(True)
time.sleep(0.15)

print("  Encendiendo el controlador...")
cmd(0x01)                       # reset por software
time.sleep(0.15)
cmd(0x3A, b"\x55")              # 16 bits por pixel
cmd(0x36, b"\x48")              # orientacion
cmd(0x11)                       # salir de reposo
time.sleep(0.15)
cmd(0x29)                       # encender
time.sleep(0.15)


def llenar(nombre, alto, bajo):
    cmd(0x2A, bytes([0, 0, 0, 239]))        # columnas 0..239
    cmd(0x2B, bytes([0, 0, 0x01, 0x3F]))    # filas 0..319
    cmd(0x2C)
    dc.write(True)
    bloque = bytes([alto, bajo]) * 2048     # 4096 bytes por envio
    for _ in range(38):                     # 240*320*2 = 153600 bytes
        spi.transfer(bloque)
    print("  -> deberia verse %s" % nombre)
    time.sleep(2)


llenar("ROJO", 0xF8, 0x00)
llenar("VERDE", 0x07, 0xE0)
llenar("AZUL", 0x00, 0x1F)

spi.close()
dc.close()
rst.close()
irq.close()

print("\n" + "=" * 58)
print("Reporta: en que prueba fallo, y si la pantalla cambio de color.")
print("Si los colores salieron en otro orden, el dato es ese orden.")
print("=" * 58)
